function [T] = DHToTransf(a, alph, d, nu)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
T = [cos(nu) -sin(nu)*cos(alph) sin(nu)*sin(alph) a*cos(nu);
    sin(nu) cos(nu)*cos(alph) -cos(nu)*sin(alph) a*sin(nu);
    0 sin(alph) cos(alph) d;
    0 0 0 1];
end

