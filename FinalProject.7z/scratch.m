clear all;
%% Inputs
a1 = 1;
a2 = 1;
%   theta d a alpha

robot = SerialLink([
    Link('d', 0, 'a', a1, 'alpha', 0, 'm', 1, 'r', [-0.5 0 0], 'I', [0 0 0], 'B', 0, 'G', 0, 'Jm', 0, 'standard', 'qlim', [-pi, pi])
    Link('d', 1, 'a', a2, 'alpha', 0, 'm', 1, 'r', [-0.5 0 0], 'I', [0 0 0], 'B', 0, 'G', 0, 'Jm', 0, 'standard', 'qlim', [-pi, pi])
    Link('d', 0, 'a', a2, 'alpha', 0, 'm', 1, 'r', [-0.5 0 0], 'I', [0 0 0], 'B', 0, 'G', 0, 'Jm', 0, 'standard', 'qlim', [-pi, pi])
    ], ...
    'name', 'two link', ...
    'comment', 'from Spong, Hutchinson, Vidyasagar');

gridRes = 10;
points = workspaceFinder(robot, gridRes);


pointsBnd = boundary(points, 0.8);
if isempty(pointsBnd) % if planar
    pointsBnd = boundary(points(:,1:2));

    if 0
        scatter3(app.axesWorkspace, points(:,1), points(:,2), points(:,3));
    end
    tri = delaunayTriangulation(points(pointsBnd,1:2));
   % bnd = boundaryshape(tri);
    %plot(bnd, 'FaceColor','red','FaceAlpha',0.1);

else
    tri = delaunayTriangulation(points);
    [bndCon, bndPts] = freeBoundary(tri);
    bnd = points(bndCon,:);
    hold on;
    scatter3(points(:,1), points(:,2), points(:,3));

    %plt = fill3(bnd(:,1), bnd(:,2), bnd(:,3), 'r');
    hold off;
    %set(plt, 'facealpha', 0.2);
    %trisurf(pointsBnd, points(:,1), points(:,2), points(:,3),'Facecolor','red','FaceAlpha',0.1, app.axesWorkspace);

end
% figure;
% bnd = points(bndCon);
% hold on;
% plot3(points(:,1), points(:,2), points(:,3))
% plot3(bnd(:,1), bnd(:,2), bnd(:,3), '+r');
% %tetramesh(tri,'FaceAlpha',0.3);
% trisurf(pointsBnd, points(:,1), points(:,2), points(:,3),'Facecolor','red','FaceAlpha',0.1);
% hold off;

