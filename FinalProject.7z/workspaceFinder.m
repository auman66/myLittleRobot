function [cloud] = workspaceFinder(robot, meshSize)
%%% Returns a pointcloud with x,y,z points as rows for the workspace. Works well with fill3 and scatter3.
%%% Keep meshSize small as possible for speed purposes.
    
%% mesh the domain
% preallocate: know we'll need a k^n number of rows (spacing) and n number of cols
linkNum = length(robot.links);
pointNum = meshSize^linkNum;
domainMesh = zeros([pointNum, linkNum]); %#ok<PREALL>
linSpacedCells = cell(1, linkNum);

% make the mesh for each dimension
for i=1:linkNum
    linSpacedCells{i} = linspace(robot.links(i).qlim(1), robot.links(i).qlim(2), meshSize);
end

% make cartesian product for each dimension
[cartProdCell{1:linkNum}] = ndgrid(linSpacedCells{:});
domainMesh = reshape(cat(meshSize, cartProdCell{:}), pointNum, linkNum);

% runs the meshed domain through fkine and then gets the point cloud
homTrans = robot.fkine(domainMesh);
cloud = squeeze(homTrans(1:3,4,:))';
    
end

