function [z, linkLen, vertOffset, angOffset] = DHToGeometry(d, theta, a, alpha)
% converts DH parameters to equivalent geometry
z = [sin(theta)*sin(alpha); -cos(theta)*sin(alpha); cos(alpha)];
linkLen = a;
vertOffset = d;
angOffset = theta;
end

